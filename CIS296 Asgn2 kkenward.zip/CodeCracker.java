/**
 * filename: CodeCracker.java
 * 
 * Class: CodeCracker
 * fields: codeString, columns, rows
 * methods: CodeCracker(newCodeString, newColumns),
 * 			crackCode(), reverseRows(), deColumnize(), removeSpaces()
 *
 * Handles the translations of the encrypted message
 * using each method to modify the string.
 */

/**
 * @author Karen Kenward
 * CIS 296 Java Programming
 * Assignment 2  Due: 2/26/2010
 */
public class CodeCracker {
	
	private StringBuilder codeString = new StringBuilder();		// message string of type StringBuilder
	private int columns = 0;									// number of columns used in message
	private int rows = 0;										// number of rows used in message
	
	// private Constructor
	private CodeCracker(){
	}
	
	/**
	 * @param inString
	 * @param newColumns
	 * Overloaded Constructor
	 * Initializes codeString, columns, and calculates rows
	 */
	public CodeCracker(StringBuilder inString, int newColumns){
		codeString=inString;
		columns = newColumns;
		rows = codeString.length()/columns;
	}
	
	/**
	 * @return StringBuilder
	 * Calls methods reverseRows(), deColumnize(), removeSpaces()
	 * to translate the coded message string.
	 */
	public StringBuilder crackCode(){
		reverseRows();
		deColumnize();
		removeSpaces();
		return codeString;
	}

	/**
	 * Reverses every other row of message string
	 */
	private void reverseRows() {
		StringBuilder tmp = new StringBuilder();
		int begin = 0;
		int end = 0;

		for (int r = 1; r < rows; r += 2){						// alternating rows
			begin = r * columns;
			end = begin + columns;
			tmp.append(codeString.substring(begin, end));		// get substring
			tmp.reverse();										// reverse substring
			codeString.replace(begin, end, tmp.toString());		// replace substring
			tmp.delete(0, tmp.length());						// clear substring
		}
	}

	/**
	 * Collapse columns into original message string 
	 */
	private void deColumnize() {
		StringBuilder tmp = new StringBuilder();
		
		for (int c = 0; c < columns; c++) {						// iterate through each column
			for (int r = 0; r < rows; r++) {					// iterate through each row
				tmp.append(codeString.charAt((r * columns) + c));	// get the char at row-column offset and append to new string
			}
		}
		codeString = tmp;		// update message
	}

	/**
	 * Remove all spaces from decoded message
	 */
	private void removeSpaces() {
		while (codeString.indexOf(" ") > 0) {					// while string contains " ", delete it
			codeString.deleteCharAt(codeString.indexOf(" "));
		}
	}
}
