/**
 * filename: CrypticCondiments.java
 * 
 * Read an input file ("input.txt") of coded messages,
 * which consist of 1 integer indicating columns and
 * a string with the encryted message.
 * Break the message into rows containing the specified number
 * of columns, with alternating rows reversed.
 * Then rewrite the columns into the original message string.
 * Write the decrypted message to a GUI dialog box
 * and an output file ("output.txt").
 */

import java.util.*;
import java.io.*;
import javax.swing.JOptionPane;

/**
 * @author Karen Kenward
 * CIS 296 Java Programming
 * Assignment 2  Due: 2/26/2010
 */
public class CrypticCondiments {

	/**
	 * @param args
	 * @throws FileNotFoundException 
	 */
	public static void main(String[] args) throws FileNotFoundException {
		// set up file i/o
		// input
		File inputFile = new File("input.txt");
		Scanner input = new Scanner(inputFile);
		
		// output
		File outputFile = new File("output.txt");
		PrintWriter output = new PrintWriter(outputFile);
		
		// variable declarations
		StringBuilder result = new StringBuilder();
		StringBuilder inString = new StringBuilder();
		int numberOfColumns = 0;
		
		// get column input from file
		numberOfColumns = input.nextInt();
		while (numberOfColumns != 0)
		{
			// get coded message input from file
			inString.append(input.nextLine());
			inString.delete(0, inString.length());
			inString.append(input.nextLine());
			
			// process input using CodeCracker class
			CodeCracker myCodeCracker = new CodeCracker(inString, numberOfColumns);
			result.append(myCodeCracker.crackCode());
			
			// display result
			JOptionPane.showMessageDialog(null, result);
			
			// output result to file
			output.println(result);
			result.delete(0, result.length());
			
			// get next column input
			numberOfColumns = input.nextInt();				
		}
		
		// close i/o
		input.close();
		output.close();
	}
}

