
package puzzle15;

import javax.swing.*;

/**
 * filename: Main.java
 *
 * CIS296 Java Programming
 * Assignment #3
 * Due: 3/26/2010
 *
 * @author Karen Kenward
 *
 * Puzzle 15 recreates a classic puzzle in which 15 numbered tiles are placed in a 4 by 4 grid,
 * leaving one empty space.  The tiles are scrambled and the player must slide the tiles into
 * numerical order.  Only the tiles which are adjacent to the empty space may be moved.
 * Puzzle 15 game uses 15 numbered buttons, and one left blank to represent the empty space.
 * The player must click the Scramble button to rearrange tiles.  Tiles next to the Blank tile
 * can be moved by clicking on them.  When all the tiles have been returned to their original
 * positions, a message box will appear.  The player may opt to have the puzzle solved
 * automatically by clicking the Solve button.
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // create an instance of PuzzleFrame
        PuzzleFrame pf = new PuzzleFrame();
        // set the properties for the game window
        pf.setTitle("Puzzle 15");               // window title
        pf.setSize(400, 400);                   // window size
        pf.setLocationRelativeTo(null);         // relative position on screen
        pf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);      // action when close is clicked
        pf.setVisible(true);                    // show the PuzzleFrame
    }
}
