
package puzzle15;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

/**
 * filename: PuzzleFrame.java
 * 
 * CIS296 Java Programming
 * Assignment #3
 * Due: 3/26/2010
 *
 * @author Karen Kenward
 * 
 * PuzzleFrame builds the game window using Tile objects placed in a 4x4 grid.
 * It defines actionListeners for the tiles and buttons so they can be moved and
 * scrambled.  Also provides option to solve the puzzle and check for the win.
 */
public class PuzzleFrame extends JFrame {
    public Tile blankTile;                              // Blank space
    public ArrayList tileArray = new ArrayList();       // Array containing the 15 tiles
    private final int SCRAMBLEMOVES = 500;              // number of moves to scramble tiles

    /*
     * PuzzleFrame Constructor
     * Build the game window, with buttons, tiles and actionListeners
     */
    public PuzzleFrame() {
        JPanel mainPanel = new JPanel();                // main panel
        mainPanel.setLayout(new BorderLayout());        // divided into center and south

        // create instance of panel with grid layout 4x4
        JPanel puzzlePanel = new JPanel();
        puzzlePanel.setLayout(new GridLayout(4, 4, 5, 5));

        // create 15 Tile buttons with anonymous ActionListeners to call Tile.moveTile() and checkForWin()
        for (int i = 1; i <= 15; i++) {
            Tile t = new Tile("" + i);
            puzzlePanel.add(t);                          // add Tile to puzzlepanel
            tileArray.add(t);                            // add Tile to tileArray
            t.addActionListener(new ActionListener() {
               public void actionPerformed(ActionEvent e) {
                   Tile te = (Tile)e.getSource();        // get the object that was acted upon
                   te.moveTile();
                   checkForWin();
               }
            });
        }

        blankTile = new Tile ("Blank");                 // create blank tile
        blankTile.setName("Blank");
        blankTile.setBackground(Color.DARK_GRAY);
        puzzlePanel.add(blankTile);                     // add it to puzzlepanel

        mainPanel.add(puzzlePanel, BorderLayout.CENTER);    // add puzzlepanel to mainpanel
        
        // create scramble button with anonymous ActionListeners to call scramble()
        JButton scrambleButton = new JButton();
        scrambleButton.setText("Scramble");
        scrambleButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                   scramble();
               }
            });

        // create solve button with anonymous ActionListeners to call solve()
        JButton solveButton = new JButton();
        solveButton.setText("Solve");
        solveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                   solve();
               }
            });

        JPanel buttonPanel = new JPanel();              // create panel for buttons
        buttonPanel.setLayout(new FlowLayout());        // with simple flow layout
        buttonPanel.add(scrambleButton);                // add the buttons
        buttonPanel.add(solveButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);     // add buttonpanel to mainpanel
    
        add(mainPanel);                      // add mainpanel to this frame
    }

    /*
     * Calls setHomeLocations() before randomly selecting tiles and calling moveTile()
     * Makes SCRAMBLEMOVES number of random moves.
     */
    public void scramble() {
        setHomeLocations();   // first, save home locations

        //randomly move tiles for SCRAMBLEMOVES moves
        java.util.Random rand = new java.util.Random();
        int moves = 0;
        while (moves < SCRAMBLEMOVES) {
            int i = rand.nextInt(15);                   // get random tile
            Tile t = (Tile)tileArray.get(i);
            boolean moved = t.moveTile();
            if (moved) {                    // if tile was moved successfully
                moves++;                    // then count it
            }
        }
    }

    /*
     * Pops each moved tile off moveStack and calls moveTile()
     * Does not optimize moves.
     */
    public void solve() {
        Tile.solving = true;                        // set so moves are not added to moveStack

        while (!Tile.moveStack.empty()) {
            Tile t = (Tile)Tile.moveStack.pop();    // remove each tile from stack
            boolean moved = t.moveTile();           // move tile
        }

        Tile.solving = false;
        
        int x = checkForWin();                      // confirm the win
    }

    /*
     * Compare each tiles' current location with its home location and
     * returns number of tiles in correct position.
     */
    private int checkForWin() {
        int tilesInPosition = 0;                            // number of tiles in position
        for (int i = 0; i < tileArray.size(); i++) {        // check every tile
            Point homeLocation = new Point();               // get home position
            homeLocation = ((Tile)tileArray.get(i)).getHomeLocation();
            Point curLocation = new Point();                // get current position
            ((Tile)tileArray.get(i)).getLocation(curLocation);
            if (curLocation.equals(homeLocation)) {         // if positions are the same
                tilesInPosition++;                          // then increment counter
            }
        }
        if (tilesInPosition == 15) {                        // if all 15 tiles in position
            JOptionPane.showMessageDialog(null, "You Win!!");
            Tile.moveStack.clear();                         // clear moveStack for new puzzle
        }
        return tilesInPosition;
    }

    /*
     * For each tile, store the current location in homeLocation
     */
    private void setHomeLocations() {
        for (int i = 0; i < tileArray.size(); i++) {
            Point homePoint = new Point();                  // save current locations as home locations
            ((Tile)tileArray.get(i)).getLocation(homePoint);
            ((Tile)tileArray.get(i)).setHomeLocation(homePoint);
        }
    }
}
