
package puzzle15;

import javax.swing.*;
import java.awt.*;
import java.util.Stack;

/**
 * filename: Tile.java
 *
 * CIS296 Java Programming
 * Assignment #3
 * Due: 3/26/2010
 *
 * @author Karen Kenward
 *
 * Tile class extends JButton by adding a homeLocation, moveStack, solving.
 * It tracks the location and controls the movement of the tiles.
 */
public class Tile extends JButton {
    private Point homeLocation;                         // starting position
    public static Stack moveStack = new Stack();        // stack of all tiles moved
    public static boolean solving = false;              // indicates if solve() is running

    /*
     * Tile Constructor
     * @param newText string to appear on Tile
     */
    public Tile(String newText) {
        this.setText(newText);          // set the text for the tile
    }

    /*
     * return homeLocation
     * Returns the starting position of the tile.
     */
    public Point getHomeLocation() {
        return homeLocation;
    }

    /*
     * Set the starting position of the tile.
     */
    public void setHomeLocation(Point homeLocation) {
        this.homeLocation = homeLocation;
    }    

    /*
     * return moved boolean
     * Look for components, left, right, above, below this Tile.
     * Check if the components match the Blank Tile, then call switchTiles() and
     * push Tile to moveStack.
     */
    public boolean moveTile() {
        boolean moved = false;
        Point tilePoint = new Point();
        Point nextPoint = new Point();
        this.getLocation(tilePoint);
        // check for components adjacent to this Tile location
        // right
        nextPoint.setLocation(tilePoint.x + this.getSize().width + 6, tilePoint.y + 1);
        Component right = this.getParent().findComponentAt(nextPoint);
        // left
        nextPoint.setLocation(tilePoint.x - this.getSize().width, tilePoint.y + 1);
        Component left = this.getParent().findComponentAt(nextPoint);
        // above
        nextPoint.setLocation(tilePoint.x + 1, tilePoint.y - this.getSize().height);
        Component above = this.getParent().findComponentAt(nextPoint);
        // below
        nextPoint.setLocation(tilePoint.x + 1, tilePoint.y + this.getSize().height + 6);
        Component below = this.getParent().findComponentAt(nextPoint);

        // if a component is adjacent, and it's the blank tile, and not solving
        // then push to moveStack and switch tiles
        if (right != null) {
            if ((right.getName()!= null) && (right.getName().equals("Blank"))) {
                // switch with blank on right
                System.out.println("move " + this.getText() + " right");
                if (!solving) {
                    moveStack.push(this);
                }
                moved = true;
                switchTiles(right);
            }
        }
        if (left != null) {
            if ((left.getName()!= null) && (left.getName().equals("Blank"))) {
                // switch with blank on left
                System.out.println("move " + this.getText() + " left");
                if (!solving) {
                    moveStack.push(this);
                }
                moved = true;
                switchTiles(left);
            }
        }
        if (above != null) {
            if ((above.getName()!= null) && (above.getName().equals("Blank"))) {
                // switch with blank above
                System.out.println("move " + this.getText() + " up");
                if (!solving) {
                    moveStack.push(this);
                }
                moved = true;
                switchTiles(above);
            }
        }
        if (below != null) {
            if ((below.getName()!= null) && (below.getName().equals("Blank"))) {
                // switch with blank below
                System.out.println("move " + this.getText() + " down");
                if (!solving) {
                    moveStack.push(this);
                }
                moved = true;
                switchTiles(below);
            }
        }

        return moved;           // return whether move was successful
    }

    /*
     * @param c Component
     * Swaps the positions of this Tile and c.
     */
    public void switchTiles(Component c) {
        Point swap = new Point();
        swap.setLocation(c.getLocation());
        c.setLocation(this.getLocation());
        this.setLocation(swap.getLocation());
        repaint();              // update the game screen
    }
}
