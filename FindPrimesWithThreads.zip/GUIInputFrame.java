/**
 * filename: GUIInputFrame.java
 * 
 * Builds the input GUI, using a ProgressBar and SwingWorker.
 * Compute all the primes and display in the textarea.
 */

import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.*;
import javax.swing.*;

/**
 * @author Karen Kenward
 * CIS 296 Java Programming
 * Assignment 4  Due: 4/13/2010
 */
public class GUIInputFrame extends JFrame {
	
	private static final long serialVersionUID = -7260049753028962208L;		// don't know why it made me add this
	
	protected JProgressBar progressBar = new JProgressBar();		// progress of threads
	private JTextArea txtAreaPrimes = new JTextArea();				// display the primes
	private JTextField txtMax = new JTextField(8);					// text of number to search up to
	private JButton btnFindPrimes = new JButton("Find Primes");		// button to initiate SwingWorker and threads
	
	public static SynchronizedCounter counter = new SynchronizedCounter();		// completed work counter

	public GUIInputFrame() {
		
		progressBar.setValue(0);
		progressBar.setMaximum(100);
		
		JPanel panel = new JPanel();								// initialize a panel
		panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		
		panel.add(new JLabel("Enter the upper range for finding prime numbers."));
		panel.add(new JLabel("(Enter 10 or multiples of 10.)"));
	
		JPanel panelRange = new JPanel();							// another panel for input field and label
		panelRange.add(new JLabel("Range:  1 to "));
		panelRange.add(txtMax);
		panel.add(panelRange);										// add panelRange to main panel
		
		JPanel panelButton = new JPanel();							// another panel for the button
		panelButton.add(btnFindPrimes);	
		panel.add(panelButton);										// add panelButton to main panel
		
		JScrollPane scroll = new JScrollPane(txtAreaPrimes);		// put textarea in a scroll pane
		scroll.setPreferredSize(new Dimension(350,250));
		txtAreaPrimes.setLineWrap(true);
		panel.add(scroll);											// add to main panel
		
		panel.add(progressBar);										// add progress bar
		
		add(panel);													// add main panel to frame
		
		btnFindPrimes.addActionListener(new ActionListener()		// define button action listeners
		{
			public void actionPerformed(ActionEvent e)
			{
				FindPrimes swingTask = new FindPrimes(Integer.parseInt(txtMax.getText()), txtAreaPrimes);
				swingTask.addPropertyChangeListener(new PropertyChangeListener()
				{													// add property change listener for updating progress bar
					public void propertyChange(PropertyChangeEvent e)
					{
						if ("progress".equals(e.getPropertyName()))
						{
							progressBar.setValue((Integer) e.getNewValue());		// update progress bar
							if ((progressBar.getValue() == 100)	&& (counter.value() == Integer.parseInt(txtMax.getText())))					// see if work is done
							{
								System.out.println("complete");
								try {
									boolean ok = FindPrimes.output();				// output results to file
									if (ok) txtAreaPrimes.append(" * File Complete *");
								} catch (FileNotFoundException ex) {
									System.err.println("FileNotFoundException: " + ex.getMessage());
								}
							}
						}
					}
				});
				swingTask.execute();								// start task in background
			}
		});

	}
	
	/** Task class for SwingWorker */
	static class FindPrimes extends SwingWorker<Integer, Integer>
	{
		private int number;											// number entered in GUI
		private JTextArea result;									// Textarea in GUI
		public static Set<Integer> resultSet;						// set automatically synchs and sorts primes
		
		/** Constructor for runnable Task */
		public FindPrimes(int number, JTextArea result)
		{
			this.number = number;
			this.result = result;
			resultSet = Collections.synchronizedSortedSet(new TreeSet<Integer>());
		}

		/** Code to run in background */
		protected Integer doInBackground()
		{
		    ExecutorService executor = Executors.newFixedThreadPool(10);	// thread pool
		    // break down work into 10 threads, starting with largest numbers first, equal batches, not balanced
		    for (int i = 9; i >= 0; i--) {
		    	int begin = (number/10) * i + 1; 
		    	int end = (number/10) * i + (number/10);
		    	executor.execute(new ComputeTask(begin, end));				// launch threads
		    }
		    executor.shutdown();											// stop threads
			return 0; 														// doInBackground must return a value
		}
		
		/** Overrides SwingWorker.process() */
		protected void process(java.util.List<Integer> list)
		{
			for (int i = 0; i < list.size(); i++) {							// list contains chunks of published primes
				result.append(list.get(i) + " ");							// add primes to textarea
				resultSet.add(list.get(i));									// add primes to result set
			}
		}
				
		/** write result set to output.txt file */
		public static boolean output() throws FileNotFoundException {
			File outputFile = new File("output.txt");						// instantiate file
			PrintWriter output = new PrintWriter(outputFile);				// open file with printwriter
			
			output.println(resultSet);										// write resultSet, it isn't pretty!

			output.close();													// close file
			return true;													// successful
		}

		/** Task for threads to run */
		public class ComputeTask implements Runnable {
			private int begin;							// beginning of number range to process
			private int end;							// end of number range to process
			
			/** Constructor */
			public ComputeTask(int begin, int end) {
				this.begin = begin;
				this.end = end;
			}
			
			/** Runnable class needs run() */
			public void run() {
				// for each number in the range, test if it is prime
				for (int i = begin; i <= end; i++) {
					if (isPrime(i)) {
						publish(i);						// send number to swingworker
					}
					counter.increment();				// increment synchronized counter
					setProgress((counter.value() * 100) / number);		//update progress
		        }
				System.out.println(begin + "-" + end + " done");
			}
			
			/** Actual test for whether number is prime */
			public boolean isPrime(int value) {
				// try dividing by each number between 2 and half the value
				for (int i = 2; i <= value/2; i++) {
					if (value % i == 0) {					// if it divides evenly, value is not prime
						return false;				
					}
				}
				return true;		// value is prime
			}
		}		
	}
}
