/**
 * filename: SynchronizedCounter.java
 * 
 * Creates a synchronized counter for threads to track progress.
 */

/**
 * @author Karen Kenward
 * CIS 296 Java Programming
 * Assignment 4  Due: 4/13/2010
 */
public class SynchronizedCounter {
	    private int c = 0;							// counter for the threads

	    public synchronized void increment() {		// only one thread can increment at a time
	        c++;
	    }

	    public synchronized void decrement() {		// not being used
	        c--;
	    }

	    public synchronized int value() {			// one thread can access value at a time
	        return c;
	    }

}
