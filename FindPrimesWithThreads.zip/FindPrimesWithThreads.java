/**
 * filename: FindPrimesWithThreads.java
 * 
 * Create a GUI program to input a number and find all the primes between 1 and that number.
 * Use SwingWorker, ProgressBar and 10 threads to process and display the primes.
 */

import javax.swing.*;

/**
 * @author Karen Kenward
 * CIS 296 Java Programming
 * Assignment 4  Due: 4/13/2010
 */
public class FindPrimesWithThreads {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		GUIInputFrame frame = new GUIInputFrame();				// instantiate the GUI frame
		frame.setTitle("Find Primes With Threads");				// title the frame
		frame.setSize(400, 300);								// determine size of frame
		frame.setLocationRelativeTo(null); 						// center the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	// set to exit program when frame closes
		frame.setVisible(true);									// make visible
	}
	
}
