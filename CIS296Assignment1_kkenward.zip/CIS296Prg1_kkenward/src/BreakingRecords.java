import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * filename: BreakingRecords.java
 * 
 * Read an input file ("input.txt") of fractions: a / b + c / d
 * Sum each pair of fractions, determine whether result is
 * a fraction: x / y  or whole number: x  or mixed number: x and y / z.
 * Write answer to console.
 */

/**
 * @author Karen Kenward
 * CIS 296 Java Programming
 * Program 1  Due: 2/9/2010
 */
public class BreakingRecords
{
	/**
	 * @param args
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		// TODO Auto-generated method stub
				
		// declare variables
		int numerator1 = 1, numerator2 = 1, denominator1 = 1, denominator2 = 1;
		int numeratorSum = 1, commonDenominator = 1, wholeSum = 0;
		int gcd = 1;						// greatest common divisor
		String eof = "0 / 0 + 0 / 0";		// end of file delimiter
		
		// get input
		//redirects STDIN to read from file
		System.setIn(new FileInputStream("input.txt"));
		//Use Scanner to read from file:
		Scanner s = new Scanner(System.in);
		String text = s.nextLine();
		
		while (!text.equals(eof))			// loop until end of file string
		{
			// parse input text
			String[] substrings = new String[4];
			substrings = text.split("[/+]");			// split text into 4 strings
			numerator1 = Integer.valueOf(substrings[0].trim());
			denominator1 = Integer.valueOf(substrings[1].trim());
			numerator2 = Integer.valueOf(substrings[2].trim());
			denominator2 = Integer.valueOf(substrings[3].trim());
			
			// common denominators
			commonDenominator = denominator1 * denominator2;
			// sum of numerators
			numeratorSum = (numerator1 * denominator2) + (numerator2 * denominator1);
			// divide out whole number
			wholeSum = numeratorSum / commonDenominator;
			numeratorSum %= commonDenominator;
			// get gcd of fraction
			gcd = greatestCommonDivisor (numeratorSum, commonDenominator);
			// reduce fraction
			numeratorSum /= gcd;
			commonDenominator /= gcd;
			
			// print results
			if (wholeSum == 0)									// less than 1
				System.out.println(numeratorSum + " / " + commonDenominator);
			else if (numeratorSum % commonDenominator == 0)		// whole number
				System.out.println(wholeSum);
			else												// mixed number
				System.out.println(wholeSum + " and " + numeratorSum + " / " + commonDenominator);
			
			// read next line
			text = s.nextLine();
		}
	}

	/**
	 * method: greatestCommonDivisor
	 * @param numerator
	 * @param denominator
	 * @return integer			// either numerator or recursive call to greatestCommonDivisor
	 * 	
	 * Use Euclid's algorithm with recursion to find the Greatest Common Divisor of 2 integers
	 */
	private static int greatestCommonDivisor(int numerator,	int denominator)
	{
		// TODO Auto-generated method stub
		
		if (denominator == 0)		// can't go any further, return to previous call with numerator as gcd
			return numerator;
		else						// call itself with denominator and remainder
			return greatestCommonDivisor(denominator, numerator % denominator);
	}
}
