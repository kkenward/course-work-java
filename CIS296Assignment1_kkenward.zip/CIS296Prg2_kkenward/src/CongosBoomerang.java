import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * filename: CongosBoomerang.java
 * 
 * Read an input file ("input.txt") of fields, with one line describing each
 * x by y field, followed by x lines of y characters of '#' and '.'.
 * Each field is tested for the number of ways a specific boomerang may be
 * thrown to land on '.'s.
 * Boomerang:  ##
 *              #
 */

/**
 * @author Karen Kenward
 * CIS 296 Java Programming
 * Program 2  Due: 2/9/2010
 */
public class CongosBoomerang
{
	/**
	 * @param args
	 */
	public static void main(String[] args) throws FileNotFoundException
	{
		// TODO Auto-generated method stub
		
		// initialize variables
		int fieldNum = 0;				// number of fields processed
		String eof = "0 0";				// end of file delimiter

		//redirects STDIN to read from file
		System.setIn(new FileInputStream("input.txt"));
		//Use Scanner to read from file:
		Scanner s = new Scanner(System.in);
		String text = s.nextLine();
		
		while (!text.equals(eof))		// loop until end of file string
		{
			fieldNum ++;
			
			// parse input string for field parameters
			String[] substring = new String[2];
			substring = text.split(" ");	
			int rows = Integer.valueOf(substring[0]);
			int cols = Integer.valueOf(substring[1]);
			
			// read in rows of field and store in 2D array of char
			char[][] field = new char[rows][cols];
			for (int i = 0; i < rows; i++)
			{
				text = s.nextLine();
				for (int j = 0; j < cols; j++)
				{
					field[i][j] = text.charAt(j);
				}
			}
			
			// call method to test boomerang
			int ways = testBoomerang(field);
			
			// output message
			if (ways == 0)		// no matches found
				System.out.println("Field #" + fieldNum + ": No way, Congo!");
			else				// matches found
				System.out.println("Field #" + fieldNum + ": Congo can throw his boomerang using " + ways + " different ways.");
			
			// get next line of input
			text = s.nextLine();
		}
	}

	/**
	 * method: testBoomerang
	 * @param field
	 * @return counter
     *
	 * field is a 2D char array of '.' or '#'  
	 * counter is the number of positions boomerang will fit
	 * Examines field for number of areas where boomerang will fit.
	 */
	private static int testBoomerang(char[][] field)
	{
		// TODO Auto-generated method stub
		
		int counter = 0;			// count positions found
		if (field.length >= 2 && field[0].length >= 2)		// make sure field is large enough for boomerang
		{
			for (int i = 0; i < (field.length - 1); i++)
				for (int j = 0; j < (field[i].length); j++)
				{
					// find 1 clear spot
					if (field[i][j] == '.')												// ..  ..   .    .
					{																	// .    .   ..  ..
						//check surrounding for clear spots
						if (j < field[i].length-1)	// check for right edge of field
						{
							if ((field[i][j+1] == '.') && (field[i+1][j] == '.'))
								counter ++;
							if ((field[i][j+1] == '.') && (field[i+1][j+1] == '.'))
								counter ++;
							if ((field[i+1][j] == '.') && (field[i+1][j+1] == '.'))
								counter ++;
						}
						if (j > 0)			// check for left edge of field
							if ((field[i+1][j-1] == '.') && (field[i+1][j] == '.'))
								counter ++;
					}
				}
		}
		return counter;		// return number of matches
	}
}
