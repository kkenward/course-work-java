import java.util.HashSet;
import java.util.Set;

public class makeStringArrayUnique
{
	public static String[] makeUnique(String[] list)
	{
		Set<String> h=new HashSet<String>();
		for(String i:list) h.add(i);
		return h.toArray(new String[0]);
	}
	
	public static void main(String[] args)
	{
		//Example 1:
		//Making a Unique List from String[] array
		String[] list={"Britney","Jason","Mike","Steve","Mike","Jason","Steve","Britney","Jack","Michelle"};
		
		System.out.print("Before:  ");
		for(String i:list) System.out.print(i+" "); System.out.println();
		
		list=makeUnique(list);
		
		System.out.print("After:   ");
		for(String i:list) System.out.print(i+" "); System.out.println();		
	}
}
