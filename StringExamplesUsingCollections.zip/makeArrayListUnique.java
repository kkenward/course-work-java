import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class makeArrayListUnique
{
	//ArrayList<String>
	public static ArrayList<String> makeUnique(ArrayList<String> list)
	{
		HashSet<String> h=new HashSet<String>();
		h.addAll(list);
		return new ArrayList<String>(Arrays.asList(h.toArray(new String[0])));
	}
	
	public static void main(String[] args)
	{
		//Example 2:
		//Making a Unique List from ArrayList 
		ArrayList<String> arrayList=new ArrayList<String>(Arrays.asList("Britney","Jason","Mike","Steve","Mike","Jason","Steve","Britney","Jack","Michelle"));
		
		System.out.print("Before:  ");
		for(String i:arrayList) System.out.print(i+" "); System.out.println();
		
		arrayList=makeUnique(arrayList);
		
		System.out.print("After:   ");
		for(String i:arrayList) System.out.print(i+" "); System.out.println();
		
	}
}
