import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;
import java.util.Map.Entry;

public class countNames
{
	//ArrayList<String> - counting occurrences
	public static Map<String,Integer> makeUnique(ArrayList<String> list)
	{
		Map<String,Integer> m=new TreeMap<String,Integer>();
		for(String i:list) m.put(i,m.get(i)==null?1:m.get(i)+1);	//decipher this!
		return m;		
	}
	
	public static void main(String[] args)
	{
		//Example 3:
		//Count occurrences 
		ArrayList<String> arrayList=new ArrayList<String>(Arrays.asList("Britney","Jason","Mike","Steve","Mike","Jason","Steve","Britney","Steve","Michelle"));
		
		System.out.print("Before:  ");
		for(String i:arrayList) System.out.print(i+" "); System.out.println();
		
		Map<String,Integer> m=makeUnique(arrayList);

		//printing out values from a map
		System.out.println("After:   ");
		for(Entry<String, Integer> pair:m.entrySet())
			System.out.print("word: "+pair.getKey()+"\t"+pair.getValue()+"\n");
		
	}
}
